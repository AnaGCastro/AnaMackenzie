# JDBC
entregas de atividades propostas.
- cada branch com a atividade da semana
- data limite 10/04/2020


## Entrega JDBC
#Entrega da atividade proposta no material teórico.

- Desenvolva um programa que peça para o usuário fornecer um número de conta e o saldo, e a seguir insira um registro na tabela CONTAS com os valores fornecidos pelo usuário.

- Desenvolva um programa que peça para o usuário fornecer um número de conta e, a seguir, apague o registro na tabela CONTAS com o número fornecido pelo usuário.
